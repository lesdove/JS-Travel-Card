document.getElementById('addButton').addEventListener('click', function() {
    const dropdown = document.getElementById('myDropdown');
    const selectedValue = dropdown.value;
    const selectedText = dropdown.options[dropdown.selectedIndex].text;
  
    const list = document.getElementById('myList');
    const listItem = document.createElement('li');
    listItem.textContent = selectedText;
    listItem.setAttribute('data-value', selectedValue); // Store the value
    list.appendChild(listItem);
  });